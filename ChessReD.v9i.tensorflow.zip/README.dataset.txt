# ChessReD > 2025-05-11 11:55am
https://universe.roboflow.com/chessred-vc-task/chessred-pnvwd

Provided by a Roboflow user
License: CC BY 4.0

